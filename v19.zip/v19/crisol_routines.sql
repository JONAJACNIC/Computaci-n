-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: crisol
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping events for database 'crisol'
--
/*!50106 SET @save_time_zone= @@TIME_ZONE */ ;
/*!50106 DROP EVENT IF EXISTS `ActualizarTipoSocioEvent` */;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `ActualizarTipoSocioEvent` ON SCHEDULE EVERY 1 DAY STARTS '2023-12-21 00:00:00' ON COMPLETION NOT PRESERVE ENABLE DO CALL ActualizarTipoSocio() */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
/*!50106 DROP EVENT IF EXISTS `MonthlyAportacionesEvent` */;;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `MonthlyAportacionesEvent` ON SCHEDULE EVERY 1 MONTH STARTS '2023-12-22 00:00:00' ON COMPLETION NOT PRESERVE ENABLE DO CALL GenerarAportacionesMensuales() */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
DELIMITER ;
/*!50106 SET TIME_ZONE= @save_time_zone */ ;

--
-- Dumping routines for database 'crisol'
--
/*!50003 DROP PROCEDURE IF EXISTS `ActualizarMultaContinua` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarMultaContinua`()
BEGIN
    DECLARE multa_id INT;
    DECLARE estado_multa INT;
    DECLARE fecha_actual DATE;
    DECLARE mult_val_actual DECIMAL(10, 2);

    -- Obtener la primera multa en estado 2
    SELECT pk_mult_id, fk_est_multa
    INTO multa_id, estado_multa
    FROM multa
    WHERE fk_est_multa = 2
    ORDER BY pk_mult_id
    LIMIT 1;

    -- Si no hay multas en estado 2, salir del procedimiento
    IF multa_id IS NULL THEN
        SELECT 'No hay multas en estado 2';
    ELSE
        -- Obtener la fecha actual y el valor de mult_val
        SET fecha_actual = (SELECT CURDATE());
        SET mult_val_actual = (SELECT mult_val FROM tipo_multa WHERE pk_tp_mult_id = 1);

        -- Calcular el nuevo valor de mult_val para cada día adicional
        SET mult_val_actual = mult_val_actual + 0.10;

        -- Actualizar el valor de mult_val en la tabla tipo_multa
        UPDATE tipo_multa
        SET mult_val = mult_val_actual
        WHERE pk_tp_mult_id = 1;

        -- Actualizar la multa en la tabla multa con el nuevo valor
        UPDATE multa
        SET mult_total = mult_total + (DATEDIFF(fecha_actual, fecha_actual) * mult_val_actual)
        WHERE pk_mult_id = multa_id;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ActualizarTipoSocio` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarTipoSocio`()
BEGIN
    DECLARE total_socios INT;

    -- Obtener el número total de socios
    SELECT COUNT(*) INTO total_socios FROM socio;

    -- Verificar si el número total de socios es mayor que 0 para evitar la división por cero
    IF total_socios > 0 THEN
        -- Calcular el nuevo valor para tp_val_fond_estr
		UPDATE tipo_socio
		SET tp_val_fond_estr = ROUND((SELECT cta_val FROM cuenta_caja WHERE pk_cta_id = 3) / total_socios, 2)
		WHERE pk_tp_sc IN (1, 2);
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `calcular_suma_aportaciones` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `calcular_suma_aportaciones`()
BEGIN
  DECLARE total_saldo DECIMAL(10, 2);

  -- Calcula la suma de cta_sc_saldo de la tabla cuenta_socio
  SELECT SUM(cta_sc_saldo) INTO total_saldo FROM cuenta_socio;

  -- Actualiza la tabla cuenta_caja con la suma calculada
  UPDATE cuenta_caja
  SET cta_val = total_saldo
  WHERE cta_dsc = 'Cta.Aportes Capital' and pk_cta_id = 5;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `GenerarAportacionesMensuales` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `GenerarAportacionesMensuales`()
BEGIN
    DECLARE fecha_aportacion DATE;
    
    -- Obtener el primer día del mes actual
    SET fecha_aportacion = DATE_FORMAT(NOW(), '%Y-%m-01');
    
    -- Insertar aportaciones mensuales para socios activos
    INSERT INTO aportaciones (aprt_fech, fk_fon_id, fk_cert_id, fk_cta_sc_id)
    SELECT
        fecha_aportacion,
        1 AS fk_fon_id,  -- ID del fondo (por ejemplo, 1)
        1 AS fk_cert_id, -- ID del certificado (por ejemplo, 1)
        cs.pk_cta_sc_id AS fk_cta_sc_id
    FROM
        socio s
    JOIN
        cuenta_socio cs ON s.pk_sc_id = cs.fk_sc_id
    WHERE
        s.fk_est_id = 1; -- Estado activo (cambia según tus necesidades)
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InsertarMultaParaTodos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarMultaParaTodos`()
BEGIN
    -- Verificar si ya existe una multa para los socios con más de dos fechas de aportaciones
    INSERT INTO multa (mult_total, fk_tp_mult_id, fk_est_multa, fk_cta_sc_id)
    SELECT
        (DATEDIFF(CURDATE(), MAX(aprt_fech))) * (SELECT mult_val FROM tipo_multa WHERE pk_tp_mult_id = 1) AS multa_total,
        1 AS fk_tp_mult_id,
        1 AS fk_est_multa,
        a.fk_cta_sc_id
    FROM aportaciones a
    WHERE (
        SELECT COUNT(DISTINCT aprt_fech)
        FROM aportaciones b
        WHERE a.fk_cta_sc_id = b.fk_cta_sc_id
    ) = 2
    AND NOT EXISTS (
        SELECT 1
        FROM multa m
        WHERE a.fk_cta_sc_id = m.fk_cta_sc_id AND m.fk_tp_mult_id = 1
    )
    AND aprt_fech = (
        SELECT MAX(aprt_fech)
        FROM aportaciones
        WHERE fk_cta_sc_id = a.fk_cta_sc_id
    )
    GROUP BY a.fk_cta_sc_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-03 21:57:04
