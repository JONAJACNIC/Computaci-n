-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: crisol
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login` (
  `pk_log_id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `log_usuario` varchar(15) NOT NULL,
  `log_clave` varchar(255) NOT NULL,
  `fk_rol_id` tinyint(4) NOT NULL,
  `fk_est_id` int(11) NOT NULL,
  `fk_sc_id` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`pk_log_id`,`fk_rol_id`,`fk_est_id`),
  KEY `fk_login_rol1_idx` (`fk_rol_id`),
  KEY `fk_login_estado_login1_idx` (`fk_est_id`),
  KEY `fk_login_socio1_idx` (`fk_sc_id`),
  CONSTRAINT `fk_login_estado_login1` FOREIGN KEY (`fk_est_id`) REFERENCES `estado_login` (`pk_est_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_login_rol1` FOREIGN KEY (`fk_rol_id`) REFERENCES `rol` (`pk_rol_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_login_socio1` FOREIGN KEY (`fk_sc_id`) REFERENCES `socio` (`pk_sc_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES (1,'adminUte','$2y$10$ODgJgETORAiPDGx55Zb.Nu1zWqIe752hMTURUnjgjE5EDu8DoubBi',1,1,NULL),(2,'tesoCaja','$2y$10$N3Gvj6iiVpVvsNb9XYM58.N7z3.wQeaj.gdvCBvqJrRIRFHmMjRn.',2,1,NULL),(3,'contCaja','$2y$10$ZOp5R/z2ppzjL0qZ56MQwekI4S.bZ.CHTWuZZsgbGykOR6Bt4qV2y',3,1,NULL),(5,'thomy','$2y$10$i1Z7CAW20LJ3xpPqRbKT7.r/sTuTiaNEiZCfoUCp5Vo3iEjYa.W7u',4,1,NULL),(7,'Jenny','$2y$10$jpRq0qEjQuA3xyVsFeCCzuAVVFpKe3HZO1vM/79NKfhFcr4Em265.',4,1,NULL);
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-03 21:56:42
