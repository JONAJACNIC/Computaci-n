-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: crisol
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `egreso`
--

DROP TABLE IF EXISTS `egreso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `egreso` (
  `pk_egre_id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `egre_val` decimal(10,2) NOT NULL,
  `egre_fech_ini` date NOT NULL,
  `egre_fdesm` date DEFAULT NULL,
  `fk_tp_egre_id` tinyint(4) NOT NULL,
  `fk_sc_id` smallint(6) NOT NULL,
  `fk_est_pg_pend` tinyint(4) NOT NULL,
  PRIMARY KEY (`pk_egre_id`,`fk_tp_egre_id`,`fk_sc_id`,`fk_est_pg_pend`),
  KEY `fk_egreso_tipo_egreso1_idx` (`fk_tp_egre_id`),
  KEY `fk_egreso_socio1_idx` (`fk_sc_id`),
  KEY `fk_egreso_estado_pago_pendiente1_idx` (`fk_est_pg_pend`),
  CONSTRAINT `fk_egreso_estado_pago_pendiente1` FOREIGN KEY (`fk_est_pg_pend`) REFERENCES `estado_pago_pendiente` (`pk_est_pg_pend`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_egreso_socio1` FOREIGN KEY (`fk_sc_id`) REFERENCES `socio` (`pk_sc_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_egreso_tipo_egreso1` FOREIGN KEY (`fk_tp_egre_id`) REFERENCES `tipo_egreso` (`pk_tp_egre_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `egreso`
--

LOCK TABLES `egreso` WRITE;
/*!40000 ALTER TABLE `egreso` DISABLE KEYS */;
INSERT INTO `egreso` VALUES (24,996.00,'2023-12-06','2024-03-05',2,2,1),(25,996.00,'2023-12-06','2024-03-05',3,3,1),(57,996.00,'2023-12-13','2024-03-12',2,20,1),(62,996.00,'2023-12-13','2024-03-12',2,4,1),(68,956.00,'2023-12-13','2024-03-12',2,1,1),(69,996.00,'2023-12-13','2024-03-12',2,14,1),(71,996.00,'2023-12-14','2024-03-13',1,17,1),(74,1990.60,'2023-12-26','2024-03-25',1,3,1),(77,10.00,'2023-12-26','2024-01-03',4,11,1),(78,1990.60,'2023-12-26',NULL,1,3,2),(81,1276.00,'2024-01-03',NULL,1,2,2),(82,20.00,'2024-01-03',NULL,4,11,2),(85,5.00,'2024-01-04','1970-01-01',14,11,2),(86,100.00,'2024-01-04',NULL,4,11,5),(87,5.00,'2024-01-03',NULL,5,11,1);
/*!40000 ALTER TABLE `egreso` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER tr1_egreso_liquidacion
BEFORE INSERT ON egreso
FOR EACH ROW
BEGIN
    -- Verificar si el nuevo registro tiene fk_tp_egre_id igual a 1, 2 o 3
    IF NEW.fk_tp_egre_id IN (1, 2, 3) THEN
        -- Actualizar el campo fk_est_id a 2 (inactivo)
        UPDATE socio
        SET fk_est_id = 2
        WHERE pk_sc_id = NEW.fk_sc_id;
        set new.fk_est_pg_pend=2;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER tr3_egreso_fondo
BEFORE INSERT ON egreso
FOR EACH ROW
BEGIN
IF NEW.fk_tp_egre_id IN (14, 15, 16,17) THEN
		set new.fk_est_pg_pend=2;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER tr4_egreso_gastos
BEFORE INSERT ON egreso
FOR EACH ROW
BEGIN
IF NEW.fk_tp_egre_id IN (4, 5, 6,12,17) THEN
    IF NEW.egre_val >=100 THEN
        set new.fk_est_pg_pend=5;
	else 
		set new.fk_est_pg_pend=1;
	END IF;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-03 21:56:38
